<div class="modal" id="modal-detail" tabindex="-1" role="dialog" aria-hidden="true" data-backdrop="static">
   <div class="modal-dialog modal-lg">
      <div class="modal-content">
 
   <div class="modal-header">
      <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true"> &times; </span> </button>
      <h3 class="modal-title">Detail Penjualan</h3>
   </div>
            
<div class="modal-body">
   
   <table class="table table-striped tabel-detailweek">
      <thead>
         <tr>
            <th width="30">No</th>
            <th>Kode Produk</th>
            <th>Nama Produk</th>
            <th align="right">Harga</th>
            <th>Jumlah</th>
            <th align="right">Sub Total</th>
         </tr>
      </thead>
      <tbody></tbody>   
   </table>
   
</div>
         
   </form>

         </div>
      </div>
   </div>
